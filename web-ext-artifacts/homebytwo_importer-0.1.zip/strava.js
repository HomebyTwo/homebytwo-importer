console.log("toto");
browser.browserAction.enable();